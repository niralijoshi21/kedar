<?PHP
namespace App\Controller;
use App\Controller\AppController;
use Cake\Event\Event;
use Cake\Core\Configure;
class ContactController extends AppController
{
	 public function beforeFilter(Event $event)
    {
		//parent::beforeFilter($event);
        // allow only login, forgotpassword
         //$this->Auth->allow(['index']);
    }
    public function index()
    {
		$this->loadModel('Contents');
        $content=$this->Contents->findByAlias("about")->firstOrFail();
		$this->set(compact('content'));	
		
		$this->loadModel('Services');
        $services_data=$this->Services->find('all')->where(['image !=' => '']);
		$this->set(compact('services_data'));	
    }
	
}
?>